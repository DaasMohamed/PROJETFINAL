#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdbool.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "hebergement.h"






void
on_button_af_alarme_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af_alarme;


af_alarme=lookup_widget(objet,"af_alarme");

gtk_widget_destroy(af_alarme);
af_alarme=lookup_widget(objet,"af_alarme");
af_alarme=create_af_alarme();

gtk_widget_show(af_alarme);

treeview=lookup_widget(af_alarme,"treeview_alarme");

afficher_alarme(treeview,"alarme.txt");
}


void
on_treeview_hebergement_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gint id;
	etudiant e;
	GtkWidget *pInfo;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);
	
}
}


void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af_hebergement;


af_hebergement=lookup_widget(objet,"af_hebergement");

gtk_widget_destroy(af_hebergement);
af_hebergement=lookup_widget(objet,"af_hebergement");
af_hebergement=create_af_hebergement();

gtk_widget_show(af_hebergement);

treeview=lookup_widget(af_hebergement,"treeview_hebergement");

afficher_hebergement(treeview,"hebergement.txt");
}





void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *pInfo, *bloc1, *bloc2, *bloc3,*j,*m,*y;
etudiant p;
int a=0;
char ch[20];
FILE *f;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
j=lookup_widget(objet,"mod_J_SK");
m=lookup_widget(objet,"mod_M_SK");
y=lookup_widget(objet,"mod_Y_SK");
bloc1=lookup_widget(objet,"modA");
bloc2=lookup_widget(objet,"modB");
bloc3=lookup_widget(objet,"modC");
mod4=lookup_widget(objet,"mod4");
mod5=lookup_widget(objet,"mod5");
mod6=lookup_widget(objet,"mod6");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(mod1)));
f = fopen("hebergement.txt","r");
if(f!=NULL){
while(fscanf(f,"%d %s %s %d %d %d %s %d %d %s\n",&(p.id),p.prenom,p.nom,&(p.d.j),&(p.d.m),&(p.d.a),p.bloc,&(p.chambre),&(p.tel),p.email)!=EOF)
	{
		if(p.id==id){
			a=1;
			break;
                 }
	}
fclose(f);
}
if(a==1){
gtk_entry_set_text(GTK_ENTRY(mod2),p.prenom);
gtk_entry_set_text(GTK_ENTRY(mod3),p.nom);
strcmp(p.bloc,"A")==0?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc1),TRUE):strcmp(p.bloc,"B")==0?gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc2),TRUE):gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(bloc3),TRUE);
gtk_spin_button_set_value(j,p.d.j);
gtk_spin_button_set_value(m,p.d.m);
gtk_spin_button_set_value(y,p.d.a);
gtk_combo_box_set_active(GTK_COMBO_BOX(mod4),p.chambre-1);
sprintf(ch,"%d",p.tel);
gtk_entry_set_text(GTK_ENTRY(mod5),ch);
gtk_entry_set_text(GTK_ENTRY(mod6),p.email);
}
else{
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Etudiant introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}
}


void
on_modifier_SK_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"af_hebergement");
	window2 = create_mod_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_supp_SK_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"af_hebergement");
	window2 = create_sup_heber();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_ajout_SK_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"af_hebergement");
	window2 = create_aj_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_OK_SK_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *mod1, *mod2, *mod3, *mod4, *mod5, *mod6, *bloc1, *bloc2, *bloc3, *pInfo;
etudiant e;
int c;
mod1=lookup_widget(objet,"mod1");
mod2=lookup_widget(objet,"mod2");
mod3=lookup_widget(objet,"mod3");
bloc1=lookup_widget(objet,"modA");
bloc2=lookup_widget(objet,"modB");
bloc3=lookup_widget(objet,"modC");
mod4=lookup_widget(objet,"mod4");
mod5=lookup_widget(objet,"mod5");
mod6=lookup_widget(objet,"mod6");
e.id=atoi(gtk_entry_get_text(GTK_ENTRY(mod1)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(mod2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(mod3)));
strcpy(e.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc1))==1?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc2))==1?"B":"C");
e.chambre=gtk_combo_box_get_active(GTK_COMBO_BOX(mod4))+1;
e.tel=atoi(gtk_entry_get_text(GTK_ENTRY(mod5)));
strcpy(e.email,gtk_entry_get_text(GTK_ENTRY(mod6)));
modifier_hebergement(e,"hebergement.txt");
pInfo=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,"Etudiant modifié avec succès");
	switch(gtk_dialog_run(GTK_DIALOG(pInfo)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(pInfo);
	break;
	}
}


void
on_aj_SK_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj1, *aj2, *aj3, *aj4, *aj5, *aj6, *bloc1, *bloc2, *bloc3,*j,*m,*a;
GtkCalendar *ajc;
etudiant e;
int c;
guint day, month, year;
aj1=lookup_widget(objet,"aj1");
aj2=lookup_widget(objet,"aj2");
aj3=lookup_widget(objet,"aj3");

bloc1=lookup_widget(objet,"ajA");
bloc2=lookup_widget(objet,"ajB");
bloc3=lookup_widget(objet,"ajC");
aj4=lookup_widget(objet,"aj4");
aj5=lookup_widget(objet,"aj5");
aj6=lookup_widget(objet,"aj6");
j = lookup_widget(objet,"Aj_J_SK");
m = lookup_widget(objet,"Aj_M_SK");
a = lookup_widget(objet,"Aj_Y_SK");

e.d.j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(j));
e.d.m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
e.d.a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(a));

char id[20];
strcpy(id,gtk_entry_get_text(GTK_ENTRY(aj1)));
e.id = atoi(id);
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(aj2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(aj3)));

strcpy(e.bloc,gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc1))==1?"A":gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(bloc2))==1?"B":"C");
c=gtk_combo_box_get_active(GTK_COMBO_BOX(aj4));
e.chambre = c==0?1:c==1?2:3;
e.tel=atoi(gtk_entry_get_text(GTK_ENTRY(aj5)));
strcpy(e.email,gtk_entry_get_text(GTK_ENTRY(aj6)));
ajouter_hebergement(e,"hebergement.txt");
}




void
on_reMod_SK_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"mod_hebergement");
	window2 = create_af_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_reAj_SK_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"aj_hebergement");
	window2 = create_af_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}


void
on_del_SK_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
	GtkWidget *input;
	GtkWidget *output;
	char id[20];
	int id_etudiant ;
	char texte[100];

	input = lookup_widget(objet_graphique,"idSupp_SK");
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(input)));

	id_etudiant = atoi(id);
	
	if(idExiste(id_etudiant) == 1){
		supprimer_hebergement(id_etudiant,"hebergement.txt");		
		sprintf(texte,"Votre suppression à été effectué avec succés\n");
		output = lookup_widget(objet_graphique,"suppRes_SK");
    		gtk_label_set_text(GTK_LABEL(output),texte);
		
	}
	else{
		sprintf(texte,"L'id que vous avez saisie n'existe pas\n");
		output = lookup_widget(objet_graphique,"suppRes_SK");
    		gtk_label_set_text(GTK_LABEL(output),texte);	
	}
}


void
on_reSupp_SK_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *window1;
	GtkWidget *window2;
	window1 = lookup_widget(objet,"sup_heber");
	window2 = create_af_hebergement();
  	gtk_widget_show (window2);
	gtk_widget_destroy(window1);
}

