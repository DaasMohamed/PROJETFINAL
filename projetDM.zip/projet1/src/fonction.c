#include "fonction.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include <gtk/gtk.h>
enum
{
	id,
	nom,
	qt,
	dej,
	COLUMNS,
};
	

void charger (char nomf[],ingr I[], int *n)
{
*n=0;
FILE *f=NULL;
int i=0 ;
f=fopen(nomf,"r+");
if (f!=NULL)
{
while(fscanf(f,"%s %s %d %d/%d/%d\n",(I[i].ID),I[i].NOM, &(I[i].QT), &(I[i].DE.j), &(I[i].DE.m), &(I[i].DE.a)) != EOF)
 {
   *n=*n+1;
   i++;
 }

}
else
{
printf("fichier introuvable \n");
}
fclose(f);
}
void ajouter_ingredient (ingr A, ingr I[], int *n)
{
strcpy(I[*n].ID,A.ID);
strcpy(I[*n].NOM,A.NOM);
I[*n].QT=A.QT;
I[*n].DE.j=A.DE.j;
I[*n].DE.m=A.DE.m;
I[*n].DE.a=A.DE.a;
*n=*n+1;

}
void supprimer_ingredient (char B[],ingr I[], int *n)
{
int c=-1,i;
for (i = 0; i < *n; i++)
{
if ((strcmp(I[i].ID,B)==0))
{
c=i;
}
}
if (c!=-1)
{
for (i = c; i < *n-1;i++)
 {
strcpy(I[i].ID,I[i+1].ID);
strcpy(I[i].NOM,I[i+1].NOM);
I[i].QT=I[i+1].QT;
(I[i].DE.j)=(I[i+1].DE.j);
(I[i].DE.m)=(I[i+1].DE.m);
(I[i].DE.a)=(I[i+1].DE.a);
 }
*n=*n-1;
}
}
void modifier_ingredient (char B[],ingr A, ingr I[], int n)
{
int i;
for (i = 0; i < n; i++)
{
if ((strcmp(I[i].ID,B)==0))
{
strcpy(I[i].ID,A.ID);
strcpy(I[i].NOM,A.NOM);
I[i].QT=A.QT;
I[i].DE.j=A.DE.j;
I[i].DE.m=A.DE.m;
I[i].DE.a=A.DE.a;
}
}
}


int chercher_ingredient (char B[], ingr I[], int n)
{
int c=-1,i;
for (i = 0; i < n; i++)
{
if ((strcmp(I[i].ID,B)==0))
 {
c=i;
 }
}
return c;}

void ingredient_hors_stock (date d,ingr HS[],int*s, ingr I[],int n)
{
int j=0,i;
for (i=0;i<n;i++)
 {
if ((I[i].DE.a < d.a) || (I[i].QT==0)) 
	{
	strcpy(HS[j].ID,I[i].ID);
	strcpy(HS[j].NOM,I[i].NOM);
	(HS[j].QT)=(I[i].QT);
	(HS[j].DE.j)=(I[i].DE.j);
	(HS[j].DE.m)=(I[i].DE.m);
	(HS[j].DE.a)=(I[i].DE.a);
	j++;
	}
  if(((I[i].DE.a)==(d.a)) && ((I[i].DE.m) < (d.m)))
	{
	strcpy(HS[j].ID,I[i].ID);
	strcpy(HS[j].NOM,I[i].NOM);
	(HS[j].QT)=(I[i].QT);
	(HS[j].DE.j)=(I[i].DE.j);
	(HS[j].DE.m)=(I[i].DE.m);
	(HS[j].DE.a)=(I[i].DE.a);
	j++;
	}
  if(((I[i].DE.a)==(d.a)) && ((I[i].DE.m) == (d.m)) && ((I[i].DE.j) < (d.j)))
	{
	strcpy(HS[j].ID,I[i].ID);
	strcpy(HS[j].NOM,I[i].NOM);
	(HS[j].QT)=(I[i].QT);
	(HS[j].DE.j)=(I[i].DE.j);
	(HS[j].DE.m)=(I[i].DE.m);
	(HS[j].DE.a)=(I[i].DE.a);
	j++;
	}
  
 
 }
*s=j;
}
void afficher (char nomf [],GtkWidget *liste)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    char ID[30];
    char NOM[30],ch[30];
    int QT;
    date DE;
    store=NULL;
    FILE *f;
store = gtk_tree_view_get_model(liste);
if (store==NULL)
{ 
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" ID",renderer,"text",id, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" NOM",renderer,"text",nom, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Quantite",renderer,"text",qt, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" Date_D'expiration",renderer,"text",dej, NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW (liste), column);


}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING);
f = fopen(nomf, "r");
if (f==NULL)
{
 return ;
}
else
{
 f = fopen(nomf, "a+"); 
	while(fscanf(f,"%s %s %d %s\n",ID,NOM,&QT,ch) != EOF)
      {
gtk_list_store_append (store,&iter);
gtk_list_store_set (store,&iter,id,ID,nom,NOM,qt,QT,dej,ch, -1);
      }
    fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}
}


void stocker (char nomf[],ingr I[], int n)
{
FILE *f=NULL;
int i=0 ;
f=fopen(nomf,"w");
if (f!=NULL)
{
for(i=0;i<n;i++)
  {
  fprintf(f, "%s %s %d %d/%d/%d\n",(I[i].ID),(I[i].NOM), (I[i].QT), (I[i].DE.j), (I[i].DE.m), (I[i].DE.a));
  }
}
fclose(f);
}
