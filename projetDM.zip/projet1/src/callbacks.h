#include <gtk/gtk.h>




void
on_DM_ajout_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_DM_supression_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_DM_sauvegarder_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttona_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonm_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonm_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonrm_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonchercher_DM_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbuttonm1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonch_DM_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbuttonrm1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttons_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonde_DM_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretour_DM_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview5_DM_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
