#include <gtk/gtk.h>
typedef struct datee
{
int j;
int m;
int a;
}date;

typedef struct ingredient
{
char ID[30];
char NOM[30];
int QT;
date DE;
} ingr;
 
void charger (char nomf[],ingr I[], int*n);
void ajouter_ingredient (ingr A, ingr I[], int*n);
void supprimer_ingredient (char B[],ingr I[], int*n);
void modifier_ingredient (char B[], ingr A, ingr I[], int n);
int chercher_ingredient (char B[], ingr I[], int n);
void ingredient_hors_stock (date d,ingr HS[],int*s, ingr I[],int n);
void afficher (char nomf [],GtkWidget *liste);
void stocker (char nomf[],ingr I[], int n);
