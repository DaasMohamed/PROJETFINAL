#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include "time.h"

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
int choix=1,n,choix1=1,choix2=1,choix3=2,s;
ingr I[200],HS[200];

void
on_DM_ajout_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAuth, *windowAffiche, *treeview1;
ingr A;
char ch[30],ch1[30];
int c;
GtkWidget *input1, *input2, *jour, *mois, *annee, *qt, *verifid ;
input1 = lookup_widget(button, "entry1_DM") ;
jour = lookup_widget(button, "spinbuttonj_DM") ;
mois = lookup_widget(button, "spinbuttonm_DM") ;
annee = lookup_widget(button, "spinbuttona_DM") ;
input2 = lookup_widget(button, "entry3_DM") ;
qt=lookup_widget(button, "comboboxqt_DM") ;
verifid = lookup_widget(button, "labelverifID_DM") ;
strcpy(A.ID,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(A.NOM,gtk_entry_get_text(GTK_ENTRY(input2)));
A.DE.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
A.DE.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
A.DE.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(ch,gtk_combo_box_get_active_text(GTK_COMBO_BOX(qt)));
A.QT=atoi(ch);
charger ("stock.txt",I,&n);
c=chercher_ingredient (A.ID,I,n);
if ((c==-1) && (strlen(A.ID)==6))
{
ajouter_ingredient (A,I,&n);
stocker ("a.txt",I,n);
remove("stock.txt");
rename("a.txt","stock.txt");
windowAffiche=lookup_widget(button,"DM_Ajout");
gtk_widget_destroy(windowAffiche);
if (choix1==1)
{
windowAuth=create_DM_Ajout();
gtk_widget_show(windowAuth);
}
if (choix1==2)
{
windowAuth=create_DM_Afficher();
gtk_widget_show(windowAuth);
treeview1=lookup_widget(windowAuth,"treeview4_DM");
  afficher ("stock.txt",treeview1);
}
}
else
{
strcpy(ch1,"Verifier votre ID");
gtk_label_set_text(GTK_LABEL(verifid),ch1);
}
}

void
on_DM_supression_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAut, *windowAffiche, *treeview1;
ingr A;
char B[30];
GtkWidget *input ;
input = lookup_widget(button, "entryc_DM") ;
strcpy(B,gtk_entry_get_text(GTK_ENTRY(input)));
charger ("stock.txt",I,&n);
supprimer_ingredient ( B,I,&n);
stocker ("a.txt",I,n);
remove("stock.txt");
rename("a.txt","stock.txt");
windowAffiche=lookup_widget(button,"DM_Suppression");
gtk_widget_destroy(windowAffiche);
if (choix3==2)
{
windowAut=create_DM_Suppression();
gtk_widget_show(windowAut);
}
if (choix3==1)
{
windowAut=create_DM_Afficher();
gtk_widget_show(windowAut);
treeview1=lookup_widget(windowAut,"treeview4_DM");
  afficher ("stock.txt",treeview1);
}
}




void
on_DM_sauvegarder_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAuth, *windowAffiche, *treeview1, *verifid;
ingr A;
int c;
char ch[30],B[30],ch1[30];
GtkWidget *input1, *input2, *input3, *jour, *mois, *annee, *qt ;
input1 = lookup_widget(button, "entry9_DM") ;
jour = lookup_widget(button, "spinbuttonj1_DM") ;
mois = lookup_widget(button, "spinbuttonm1_DM") ;
annee = lookup_widget(button, "spinbuttona1_DM") ;
input2 = lookup_widget(button, "entry10_DM") ;
input3 = lookup_widget(button, "entry7_DM") ;
qt=lookup_widget(button, "comboboxqt1_DM") ;
verifid = lookup_widget(button, "labelVERIFid_DM") ;
strcpy(A.ID,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(A.NOM,gtk_entry_get_text(GTK_ENTRY(input2)));
A.DE.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
A.DE.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
A.DE.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
strcpy(ch,gtk_combo_box_get_active_text(GTK_COMBO_BOX(qt)));
A.QT=atoi(ch);
strcpy(B,gtk_entry_get_text(GTK_ENTRY(input3)));
charger ("stock.txt",I,&n);
c=chercher_ingredient (A.ID,I,n);
if (((c==-1) && (strlen(A.ID)==6)) || ((strcmp(A.ID,B)==0) && (strlen(A.ID)==6)))
{
modifier_ingredient (B,A,I,n);
stocker ("a.txt",I,n);
remove("stock.txt");
rename("a.txt","stock.txt");
windowAffiche=lookup_widget(button,"DM_Modifier");
gtk_widget_destroy(windowAffiche);
if (choix2==1)
{
windowAuth=create_DM_Modifier();
gtk_widget_show(windowAuth);
}
if (choix2==2)
{
windowAuth=create_DM_Afficher();
gtk_widget_show(windowAuth);
treeview1=lookup_widget(windowAuth,"treeview4_DM");
  afficher ("stock.txt",treeview1);
}
}
else
{
strcpy(ch1,"Verifier votre ID");
gtk_label_set_text(GTK_LABEL(verifid),ch1);
}
}



void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ID, *output ;
int c;
char ch[90],user[30];
ID = lookup_widget(button, "entry11_DM");
strcpy(user, gtk_entry_get_text(GTK_ENTRY(ID)));
charger ("stock.txt",I,&n);
c=chercher_ingredient (user,I,n);
if (c==-1)
{
output = lookup_widget(button, "label23_DM") ;
strcpy(ch,"produit introuvable");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else 
{
output = lookup_widget(button, "label23_DM") ;
strcpy(ch,"Votre produit se trouve dans le stock");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}


void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *windowAuth, *windowAffiche;
windowAffiche=lookup_widget(button,"DM_Afficher");
gtk_widget_destroy(windowAffiche);
if (choix==1)
{
windowAuth=create_DM_Ajout();
gtk_widget_show(windowAuth);
}
if (choix==2)
{
windowAuth=create_DM_Modifier();
gtk_widget_show(windowAuth);
}
if (choix==3)
{
windowAuth=create_DM_Suppression();
gtk_widget_show(windowAuth);
}
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
choix=1;

}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
choix=2;
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
choix=3;
}
void
on_checkbuttona_toggled                (GtkToggleButton *togglebutton,
                                     gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1=1;

}

void
on_checkbuttonm_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix1=2;
}

void
on_checkbuttonrm_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix2=2;
}


void
on_buttonchercher_DM_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ID, *output ;
int c;
char ch[90],user[30],text[30];
GtkWidget *input1, *input2, *jour, *mois, *annee, *qt ;
input1 = lookup_widget(button, "entry9_DM") ;
jour = lookup_widget(button, "spinbuttonj1_DM") ;
mois = lookup_widget(button, "spinbuttonm1_DM") ;
annee = lookup_widget(button, "spinbuttona1_DM") ;
input2 = lookup_widget(button, "entry10_DM") ;
qt=lookup_widget(button, "comboboxqt1_DM");
ID = lookup_widget(button, "entry7_DM");
strcpy(user, gtk_entry_get_text(GTK_ENTRY(ID)));
charger ("stock.txt",I,&n);
c=chercher_ingredient (user,I,n);
if (c==-1)
{
output = lookup_widget(button, "label26_DM") ;
strcpy(ch,"produit introuvable");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else 
{
output = lookup_widget(button, "label26_DM") ;
strcpy(ch,"Votre produit se trouve dans le stock");
gtk_label_set_text(GTK_LABEL(output),ch);
gtk_entry_set_text (input2,I[c].NOM);
gtk_entry_set_text (input1,I[c].ID);
gtk_spin_button_set_value (jour,I[c].DE.j);
gtk_spin_button_set_value (mois,I[c].DE.m);
gtk_spin_button_set_value (annee,I[c].DE.a);

}
}


void
on_checkbuttonm1_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix2=1;
}


void
on_buttonch_DM_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ID, *output ;
int c;
char ch[90],user[30];
ID = lookup_widget(button, "entryc_DM");
strcpy(user, gtk_entry_get_text(GTK_ENTRY(ID)));
charger ("stock.txt",I,&n);
c=chercher_ingredient (user,I,n);
if (c==-1)
{
output = lookup_widget(button, "labela_DM") ;
strcpy(ch,"produit introuvable");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else 
{
output = lookup_widget(button, "labela_DM") ;
strcpy(ch,"Votre produit se trouve dans le stock");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}


void
on_checkbuttonrm1_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix3=1;
}


void
on_checkbuttons_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
choix3=2;
}


void
on_buttonde_DM_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
date F;
GtkWidget *jour1, *mois1, *annee1, *affiche, *treeview2, *windoAffiche ;
jour1 = lookup_widget(button, "spinbuttonje_DM") ;
mois1 = lookup_widget(button, "spinbuttonme_DM") ;
annee1 = lookup_widget(button, "spinbuttoae_DM") ;
F.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour1));
F.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois1));
F.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee1));
charger ("stock.txt",I,&n);
ingredient_hors_stock (F,HS,&s,I,n);
stocker ("Horsstock.txt",HS,s);
windoAffiche=lookup_widget(button,"DM_Afficher");
gtk_widget_destroy(windoAffiche);
affiche = create_Produit_hors_stock();
  gtk_widget_show (affiche);
  treeview2=lookup_widget(affiche,"treeview5_DM");
  afficher("Horsstock.txt",treeview2);

}


void
on_buttonretour_DM_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview3, *Window, *windoAffiche; 
windoAffiche=lookup_widget(button,"Produit_hors_stock");
gtk_widget_destroy(windoAffiche);
 Window = create_DM_Afficher();
  gtk_widget_show (Window);
  treeview3=lookup_widget(Window,"treeview4_DM");
  afficher ("stock.txt",treeview3);
}


void
on_treeview5_DM_row_activated          (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


}

