#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"
#include "string.h"
int radiobutt;
int t,m,d,f;
void
on_MHbutton_ajoute_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *max;
GtkWidget *min;
GtkWidget *combobox;
GtkWidget *id;
GtkWidget *gaara;
GtkWidget *numero;
GtkWidget *output;
char id1[100];
date d;
int max0 ;
char max1[100];
char min1[100];
int min0 ;
int gaara1 ;
char marque[100] ;
cap c;
char msg[100]="";
int numero0 ;
char numero1 [100];
int i;
char ch [100];
fenetre_ajout = lookup_widget (button, "MHajoutcapteur");
id = lookup_widget (button, "MHentryajoutID");
max = lookup_widget (button, "entryajoutmax");
gaara = lookup_widget (button, "spinbutton1");
numero = lookup_widget (button, "entryajoutnumero");
jour = lookup_widget (button, "spinbutton2");
mois = lookup_widget (button, "spinbutton3");
annee = lookup_widget (button, "spinbutton4");
min = lookup_widget (button, "entryajoutmin");
combobox = lookup_widget (button, "comboboxentry1");
d.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
d.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mois));
d.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(annee));
sprintf(max1,"%d",max0);
sprintf(min1,"%d",min0);
sprintf(numero1,"%d",numero0);
strcpy(max1, gtk_entry_get_text(GTK_ENTRY(max)));
strcpy(min1, gtk_entry_get_text(GTK_ENTRY(min)));
strcpy(numero1, gtk_entry_get_text(GTK_ENTRY(numero)));
gaara1=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(gaara));
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(marque, gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox)));
radio(radiobutt,msg);
max0=atoi(max1);
min0=atoi(min1);
numero0=atoi(numero1);
c.d.j=d.j;
c.d.m=d.m;
c.d.a=d.a;
c.max=max0;
c.min=min0;
c.numero= numero0;
strcpy(c.id,id1);
strcpy(c.type,msg);
strcpy(c.marque,marque);
c.gaara=gaara1;
i = chercher_capteur(id1);
if (i == 1)
{
output= lookup_widget (button, "MHverfaj");
strcpy(ch," le capteur existe  ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else 
{
output= lookup_widget (button, "MHverfaj");
strcpy(ch,"ajoutation effectuee avec succees");
gtk_label_set_text(GTK_LABEL(output),ch);
ajoute_capteur(c);
}
}



void
on_MHbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id ;
GtkWidget *output ;
char id1[100];
int c ;
char ch [100];
id= lookup_widget (button, "MHentryIsupprimerD");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
c = chercher_capteur(id1);
if (c == 1) 
{
output= lookup_widget (button, "MHlabelsupp");
strcpy(ch,"suppression effectuee avec succees");
gtk_label_set_text(GTK_LABEL(output),ch);
supprimer_capteur(id1);
}
else 
{
output= lookup_widget (button, "MHlabelsupp");
strcpy(ch," le capteur n'existe pas ");
gtk_label_set_text(GTK_LABEL(output),ch);

}
}


void
on_MHbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_modifier;
GtkWidget *jour;
GtkWidget *marque;
GtkWidget *type;
GtkWidget *output;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *max;
GtkWidget *min;
GtkWidget *combobox;
GtkWidget *idnv;
GtkWidget *numero;
GtkWidget *idold;
GtkWidget *gaara;
char ch[100];
char idold1[100];
char idnv1[100];
date d;
int max0 ;
char max1[100];
char min1[100];
int min0 ;
char numero1[100];
int numero0;
int gaara1 ;
char marque1[100] ;
char type1[100] ;
cap c;
fenetre_modifier = lookup_widget (button, "MHmodifiercapteur");
idnv = lookup_widget (button, "entrymofidiernouvid");
idold = lookup_widget (button, "MHentrymodifierID");
numero = lookup_widget (button, "entrymodifiernumero");
max = lookup_widget (button, "entrymodifiermax");
gaara = lookup_widget (button, "spinbutton8");
jour = lookup_widget (button, "spinbutton5");
mois = lookup_widget (button, "spinbutton6");
annee = lookup_widget (button, "spinbutton7");
min= lookup_widget (button, "entrymodifiermin");
marque = lookup_widget (button, "MHentrymarque");
type = lookup_widget (button, "MHentrytype");
d.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
d.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mois));
d.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(annee));
sprintf(max1,"%d",max0);
sprintf(min1,"%d",min0);
sprintf(numero1,"%d",numero0);
strcpy(max1, gtk_entry_get_text(GTK_ENTRY(max)));
strcpy(min1, gtk_entry_get_text(GTK_ENTRY(min)));
strcpy(marque1, gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(type1, gtk_entry_get_text(GTK_ENTRY(type)));
strcpy(numero1, gtk_entry_get_text(GTK_ENTRY(numero)));
gaara1=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(gaara));
strcpy(idnv1, gtk_entry_get_text(GTK_ENTRY(idnv)));
strcpy(idold1, gtk_entry_get_text(GTK_ENTRY(idold)));
max0=atoi(max1);
min0=atoi(min1);
numero0=atoi(numero1);
c.d.j=d.j;
c.d.m=d.m;
c.d.a=d.a;
c.max=max0;
c.numero=numero0;
c.min=min0;
strcpy(c.id,idnv1);
strcpy(c.type,type1);
strcpy(c.marque,marque1);
c.gaara=gaara1;
if ( ( ( strcmp (c.type,"temperature") == 0 )  ||(strcmp(c.type,"debit'd'eau")==0)||(strcmp(c.type,"fumee")==0)||(strcmp(c.type,"mouvement")==0)|| (strcmp(c.type,"TEMPERATURE")==0)||(strcmp(c.type,"DEBIT'D'EAU")==0)||(strcmp(c.type,"FUMEE")==0)||(strcmp(c.type,"MOUVEMENT")==0))&& ( (strcmp(c.marque,"MSA")==0) ||(strcmp(c.marque,"HITEC")==0)||(strcmp(c.marque,"ICA")==0)||(strcmp(c.marque,"msa")==0)||(strcmp(c.marque,"ica")==0)||(strcmp(c.marque,"hitec")==0) ) )
{
output= lookup_widget (button, "MHlabelmod");
strcpy(ch,"modfication effectuee avec succees");
gtk_label_set_text(GTK_LABEL(output),ch);
modifier_capteur(idold1,c);
}
else
{
output= lookup_widget (button, "MHlabelmod");
strcpy(ch,"verifer le type et le marque ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}
void
on_MHbuttonOk_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *idnv ;
GtkWidget *idold ;
GtkWidget *output ;
GtkWidget *fenetre_modifier;
GtkWidget *jour;
GtkWidget *mois;
GtkWidget *annee;
GtkWidget *max;
GtkWidget *min;
GtkWidget *gaara;
GtkWidget *numero;
GtkWidget *type;
GtkWidget *marque;
char id1[100];
int i = 0 ;
int c ;
cap a ;
char ch[100]="";
char max1[100];
char min1[110];
char gaara1[100];
char jour1[100];
char mois1[100];
char annee1[100];
char numero1[100];


fenetre_modifier = lookup_widget (button, "MHmodifiercapteur");
idold = lookup_widget (button, "MHentrymodifierID");
idnv = lookup_widget (button, "entrymofidiernouvid");
max = lookup_widget (button, "entrymodifiermax");
type = lookup_widget (button, "MHentrytype");
marque = lookup_widget (button, "MHentrymarque");
gaara = lookup_widget (button, "spinbutton8");
jour = lookup_widget (button, "spinbutton5");
mois = lookup_widget (button, "spinbutton6");
annee = lookup_widget (button, "spinbutton7");
min = lookup_widget (button, "entrymodifiermin");
numero = lookup_widget (button, "entrymodifiernumero");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(idold)));
c = chercher_capteur(id1);
if (c == 1)
{
a = find(id1);
sprintf(max1,"%d",a.max);
sprintf(min1,"%d",a.min);
sprintf(numero1,"%d",a.numero);
output = lookup_widget (button, "labelmodifiermes");
strcpy(ch," le capteur existe");
gtk_label_set_text(GTK_LABEL(output),ch);
gtk_entry_set_text(GTK_ENTRY(idnv),a.id);
gtk_entry_set_text(GTK_ENTRY(numero),numero1);
gtk_entry_set_text(GTK_ENTRY(max),max1);
gtk_entry_set_text(GTK_ENTRY(min),min1);
gtk_entry_set_text(GTK_ENTRY(type),a.type);
gtk_entry_set_text(GTK_ENTRY(marque),a.marque);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(gaara),a.gaara);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour),a.d.j);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois),a.d.m);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee),a.d.a);
}
else
{
output= lookup_widget (button, "labelmodifiermes");
strcpy(ch," le capteur n'existe pas ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
}

void
on_MHradiobuttontemp_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    radiobutt=1;
}


void
on_MHradiobuttoneau_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    radiobutt=2;
}


void
on_MHradiobuttonmove_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    radiobutt=3;
}


void
on_MHradiobuttonfum_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    radiobutt=4;
}




void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter ;
gchar* id;
int numero ;
gchar* marque ;
gchar* type ;
int max ;
int min ;
int gaara ;
cap c;
int jour ;
int mois ;
int annee ;


GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path))
	{
		gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&marque,2,&numero,3,&type,4,&max,5,&min,6,&gaara,7,&jour,8,&mois,9,&annee,-1);
		strcpy(c.id,id);
		strcpy(c.marque,marque);
		strcpy(c.type,type);
		c.gaara=gaara;
		c.max=max;
		c.min=min;
		c.d.j=jour;
		c.d.m=mois;
		c.d.a=annee;
		c.numero=numero;
		supprimer_capteur(id);
		afficher_capteur(treeview);
	}

}




void
on_buttontempajoute_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *jour;
GtkWidget *heure;
GtkWidget *valeur;
GtkWidget *id;
GtkWidget *numero;
GtkWidget *output;
char id1[100];
int val0 ;
char val1[100];
temp p;
int jour0;
int heure0;
char numero1[100];
int numero0;
char ch[100];
int kk;
fenetre_ajout = lookup_widget (button, "MHTEMP");
id = lookup_widget (button, "MHentrytempID");
jour = lookup_widget (button, "MHspintempjour");
heure = lookup_widget (button, "MHspintempheure");
valeur = lookup_widget (button, "entrytempval");
numero = lookup_widget (button, "MHnumero");
jour0=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
heure0=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(heure));
sprintf(numero1,"%d",numero0);
strcpy(numero1, gtk_entry_get_text(GTK_ENTRY(numero)));
sprintf(val1,"%d",val0);
strcpy(val1,gtk_entry_get_text(GTK_ENTRY(valeur)));
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
val0=atoi(val1);
numero0=atoi(numero1) ;
p.jour=jour0 ;
p.heure=heure0 ;
strcpy(p.id,id1) ;
p.numero=numero0 ;
p.valeur=val0 ;
/*kk = check (numero0);
if (kk=0)
{*/
output = lookup_widget (button, "label28tempajouter");
strcpy(ch," ajoutation effectuee avec succees ");
gtk_label_set_text(GTK_LABEL(output),ch);
ajoute_temp(p) ;
/*}
else 
{
output = lookup_widget (button, "label28tempajouter");
strcpy(ch," changer l'heure or le jour or le numero du capteur  ");
gtk_label_set_text(GTK_LABEL(output),ch);
}*/

}


void
on_MHbutton_affiajou_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;



fenetre_ajout = lookup_widget (button, "MHajoutcapteur");
gtk_widget_destroy(fenetre_ajout);
fenetre_afficher = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();
gtk_widget_show(fenetre_afficher);

treeview1 = lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);

}


void
on_afficherbuttontemp_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHaffichercapteur;
GtkWidget *MHTEMP;


MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(MHaffichercapteur);
MHTEMP = lookup_widget (button, "MHTEMP");
MHTEMP = create_MHTEMP();

gtk_widget_show(MHTEMP);

}


void
on_buttonaffichedecf_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHaffichercapteur;
GtkWidget *defectueux;
GtkWidget *treeview2;


MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(MHaffichercapteur);
defectueux = lookup_widget (button, "defectueux");
defectueux = create_defectueux();
gtk_widget_show(defectueux);
treeview2 = lookup_widget(defectueux,"treeview2");
afficher_defectueux(treeview2);
}


void
on_afficherbuttonajou_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHajoutcapteur;
GtkWidget *MHaffichercapteur;


MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(MHaffichercapteur);
MHajoutcapteur = lookup_widget (button, "MHajoutcapteur");
MHajoutcapteur = create_MHajoutcapteur();

gtk_widget_show(MHajoutcapteur);

}


void
on_afficherbuttonsup_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHsupprimercapteur;
GtkWidget *MHaffichercapteur;


MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(MHaffichercapteur);
MHsupprimercapteur = lookup_widget (button, "MHsupprimercapteur");
MHsupprimercapteur = create_MHsupprimercapteur();

gtk_widget_show(MHsupprimercapteur);

}


void
on_afficherbuttonmod_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHmodifiercapteur;
GtkWidget *MHaffichercapteur;


MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(MHaffichercapteur);
MHmodifiercapteur = lookup_widget (button, "MHmodifiercapteur");
MHmodifiercapteur = create_MHmodifiercapteur();

gtk_widget_show(MHmodifiercapteur);

}


void
on_MHAFFSUP_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_supp;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;


fenetre_supp = lookup_widget (button, "MHsupprimercapteur");

gtk_widget_destroy(fenetre_supp);
fenetre_afficher = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();

gtk_widget_show(fenetre_afficher);

treeview1 = lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);


}


void
on_MHAFFTEMP_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_temp;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;



fenetre_temp = lookup_widget (button, "MHTEMP");

gtk_widget_destroy(fenetre_temp);
fenetre_afficher = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();

gtk_widget_show(fenetre_afficher);

treeview1 = lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);

}


void
on_MHRETURNMAIN_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_defec;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;



fenetre_defec = lookup_widget (button, "defectueux");

gtk_widget_destroy(fenetre_defec);
fenetre_afficher = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();

gtk_widget_show(fenetre_afficher);

treeview1 = lookup_widget(fenetre_afficher,"treeview1");

afficher_capteur(treeview1);

}


void
on_MHRETURNAJOT_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHTEMP;
GtkWidget *defectueux;

defectueux = lookup_widget (button, "defectueux");

gtk_widget_destroy(defectueux);
MHTEMP = lookup_widget (button, "MHTEMP");
MHTEMP = create_MHTEMP();

gtk_widget_show(MHTEMP);


}


void
on_MHVERSAFF_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHTEMP;
GtkWidget *defectueux;
GtkWidget *treeview2;


MHTEMP = lookup_widget (button, "MHTEMP");

gtk_widget_destroy(MHTEMP);
defectueux = lookup_widget (button, "defectueux");
defectueux = create_defectueux();

gtk_widget_show(defectueux);

treeview2 = lookup_widget(defectueux,"treeview2");
remove("defectueux.txt");
defective_capture();
afficher_defectueux(treeview2);

}


void
on_MHMODAFF_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHsupprimercapteur;
GtkWidget *MHaffichercapteur;
GtkWidget *treeview1;


MHsupprimercapteur = lookup_widget (button, "MHsupprimercapteur");

gtk_widget_destroy(MHsupprimercapteur);
MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");
MHaffichercapteur = create_MHaffichercapteur();

gtk_widget_show(MHaffichercapteur);

treeview1 = lookup_widget(MHaffichercapteur,"treeview1");

afficher_capteur(treeview1);
}


void
on_MHACTUALISER1_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fenetre_afficher,*w1;
GtkWidget *treeview1;


w1 = lookup_widget (button, "MHaffichercapteur");
fenetre_afficher = create_MHaffichercapteur();

gtk_widget_show(fenetre_afficher);

gtk_widget_hide(w1);
treeview1 = lookup_widget(fenetre_afficher,"treeview1");
vider(treeview1);
afficher_capteur(treeview1);
}


void
on_MHACTUALISER2_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *defectueux;
GtkWidget *treeview2;


defectueux = lookup_widget (button, "defectueux");
defectueux = create_defectueux();

treeview2 = lookup_widget(defectueux,"treeview2");
choix(f,m,f,d);
afficher_type(treeview2);
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter ;
gchar* id;
int numero ;
gchar* marque ;
gchar* type ;
int max ;
int min ;
int gaara ;
cap c;
int jour ;
int mois ;
int annee ;


GtkTreeModel *model =gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model,&iter,path))
	{
		gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,1,&marque,2,&numero,3,&type,4,&max,5,&min,6,&gaara,7,&jour,8,&mois,9,&annee,-1);
		strcpy(c.id,id);
		strcpy(c.marque,marque);
		strcpy(c.type,type);
		c.gaara=gaara;
		c.max=max;
		c.min=min;
		c.d.j=jour;
		c.d.m=mois;
		c.d.a=annee;
		c.numero=numero;
		afficher_defectueux(treeview);
	}
	}



void
on_MHVERFAJOUTERTEMP_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id ;
GtkWidget *output ;
GtkWidget *output1 ;
char id1[100];
int c ;
char ch [100];
char ch1 [100];
cap a;
char numero[100];
id= lookup_widget (button, "MHentrytempID");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
c = chercher_capteur(id1);
if (c == 0) 
{
output= lookup_widget (button, "MHlabelverifier");
strcpy(ch," le capteur n'existe pas ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else 
{
a = find (id1);
output = lookup_widget (button, "MHlabelverifier");
output1 = lookup_widget (button, "MHlabelnumero");
strcpy(ch,"le capteur existe");
sprintf(numero,"%d",a.numero);
strcpy(ch1,"le max de numero de capteur est : ");
strcat(ch1,numero);
gtk_label_set_text(GTK_LABEL(output),ch);
gtk_label_set_text(GTK_LABEL(output1),ch1);
}

}


void
on_MHbuttonaffiajouter_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHajoutcapteur,*MHaffichercapteur,*treeview1;

GtkWidget *w1;

MHajoutcapteur=lookup_widget(button,"MHajoutcapteur");
MHaffichercapteur=create_MHaffichercapteur();
gtk_widget_show(MHaffichercapteur);


treeview1=lookup_widget(MHaffichercapteur,"treeview1");

afficher_capteur(treeview1);
}


void
on_MHcheckbuttondef_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
{t=1;}
else {t=0;}
}


void
on_MHcheckbutton4def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
{f=1;}
else {f=0;}
}


void
on_MHcheckbutton5def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
{d=1;}
else {d=0;}
}


void
on_MHtomodifier_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHmain;
GtkWidget *MHmodifiercapteur;

MHmain = lookup_widget (button, "MHmain");
gtk_widget_destroy(MHmain);
MHmodifiercapteur = lookup_widget (button, "MHmodifiercapteur");
MHmodifiercapteur = create_MHmodifiercapteur();
gtk_widget_show(MHmodifiercapteur);
}

void
on_MHtosupprimer_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHmain;
GtkWidget *MHsupprimercapteur;

MHmain = lookup_widget (button, "MHmain");
gtk_widget_destroy(MHmain);
MHsupprimercapteur = lookup_widget (button, "MHsupprimercapteur");
MHsupprimercapteur = create_MHsupprimercapteur();
gtk_widget_show(MHsupprimercapteur);
}


void
on_MHtoajouter_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHmain;
GtkWidget *MHajoutcapteur;

MHmain = lookup_widget (button, "MHmain");
gtk_widget_destroy(MHmain);
MHajoutcapteur = lookup_widget (button, "MHajoutcapteur");
MHajoutcapteur = create_MHajoutcapteur();
gtk_widget_show(MHajoutcapteur);
}


void
on_MHtoafficher_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHmain;
GtkWidget *MHaffichercapteur;

MHmain = lookup_widget (button, "MHmain");
gtk_widget_destroy(MHmain);
MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");
MHaffichercapteur = create_MHaffichercapteur();
gtk_widget_show(MHaffichercapteur);
}


void
on_MHbuttoncapchercher_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id ;
GtkWidget *output ;
char id1[100] ;
int c ;
char ch [100];
id= lookup_widget (button, "entry_rechercher2");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
c = chercher_capteur(id1);
if (c == 1) 
{
output= lookup_widget (button, "label_chercher3");
strcpy(ch," le menu existe ");
gtk_label_set_text(GTK_LABEL(output),ch);
}
else 
{
output= lookup_widget (button, "label_chercher3");
strcpy(ch," le menu n'existe pas ");
gtk_label_set_text(GTK_LABEL(output),ch);

}
}

void
on_MHbuttondata_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
int k;
char texte[500];
char texte2[500];
char texte3[500];
GtkCalendar *ajc,*output999;
int mois, jour , annee;
guint* day, month, year;
ajc=lookup_widget(button,"MHcalendar1");
output999=lookup_widget(button,"MHlabeldata");
gtk_calendar_get_date(GTK_CALENDAR(ajc), &day, &month, &year);
jour=year;
mois=month+1;
annee=day;

k=initialisation(jour,mois,annee);
sprintf(texte,"le nombre des etudiants qui \n ont ce date de naissance %d/%d/%d sont :\n %d",jour,mois,annee,k);
//strcpy(texte3,nbrdatee(jour,mois,annee));
//strcpy(texte2,texte3);
gtk_label_set_text(GTK_LABEL(output999),texte);
}


void
on_MHcheckbutton3def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
{m=1;}
else {m=0;}
}


void
on_buttonchercherreturn_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHcherchercapteur;
GtkWidget *MHaffichercapteur;

MHcherchercapteur = lookup_widget (button, "MHcherchercapteur");

gtk_widget_destroy(MHcherchercapteur);
MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");
MHaffichercapteur = create_MHaffichercapteur();

gtk_widget_show(MHaffichercapteur);
}


void
on_MHrchercheraff_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *MHcherchercapteur;
GtkWidget *MHaffichercapteur;

MHaffichercapteur = lookup_widget (button, "MHaffichercapteur");

gtk_widget_destroy(MHaffichercapteur);
MHcherchercapteur = lookup_widget (button, "MHcherchercapteur");
MHcherchercapteur = create_MHcherchercapteur();

gtk_widget_show(MHcherchercapteur);
}


void
on_buttonverifierprinciple_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

}

