#include <gtk/gtk.h>


void
on_MHbutton_ajoute_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttonsupprimer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttonafficher_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttonmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttonOk_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHradiobuttontemp_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHradiobuttoneau_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHradiobuttonmove_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHradiobuttonfum_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficherbutton1_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbutton2_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbutton3_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbutton4_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button8_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttontempajoute_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_MHbutton_affiajou_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbuttontemp_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichedecf_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbuttonajou_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbuttonsup_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficherbuttonmod_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHAFFSUP_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHAFFTEMP_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHRETURNMAIN_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHRETURNAJOT_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHVERSAFF_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHMODAFF_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHACTUALISER1_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHACTUALISER2_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_MHVERFAJOUTERTEMP_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHVERFAJOUTERTEMP_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHbuttonaffiajouter_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHcheckbuttondef_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHcheckbutton4def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHcheckbutton5def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_MHtomodifier_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHtosupprimer_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHtoajouter_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHtoafficher_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttoncapchercher_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHbuttondata_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHcheckbutton3def_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonchercherreturn_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_MHrchercheraff_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonverifierprinciple_clicked     (GtkButton       *button,
                                        gpointer         user_data);
