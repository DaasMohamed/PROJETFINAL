#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "utilisateur.h"



void
on_MT_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *MT_modifid, *MT_modifrole, *MT_modifprenom, *MT_modifnom, *MT_modifmail, *MT_modifniv;
GtkCalendar *MT_modcal;
guint day, month, year;
utilisateur u;
MT_modifid=lookup_widget(objet,"MT_modifid");
MT_modifrole=lookup_widget(objet,"MT_modifrole");
MT_modifprenom=lookup_widget(objet,"MT_modifprenom");
MT_modifnom=lookup_widget(objet,"MT_modifnom");
MT_modifmail=lookup_widget(objet,"MT_modifmail");
MT_modifniv=lookup_widget(objet,"MT_modifniv");
MT_modcal=lookup_widget(objet,"MT_modcal");
u.id=atoi(gtk_entry_get_text(GTK_ENTRY(MT_modifid)));
u.role = gtk_combo_box_get_active(GTK_COMBO_BOX(MT_modifrole))+1;
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(MT_modifprenom)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(MT_modifnom)));
strcpy(u.email,gtk_entry_get_text(GTK_ENTRY(MT_modifmail)));

u.nv = u.role==6?gtk_combo_box_get_active(GTK_COMBO_BOX(MT_modifniv))+1:0;


gtk_calendar_get_date(GTK_CALENDAR(MT_modcal), &year, &month, &day);
u.d.j=day;
u.d.m=month+1;
u.d.a=year;


modifier_utilisateur(u,"utilisateur.txt");
}


void
on_MT_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *MT_modifid, *MT_modifrole, *MT_modifprenom, *MT_modifnom, *MT_modifmail, *MT_modifniv, *msg;
GtkCalendar *MT_modcal;
int a=0;
char ch[20];
FILE *f;
MT_modifid=lookup_widget(objet,"MT_modifid");
MT_modifrole=lookup_widget(objet,"MT_modifrole");
MT_modifprenom=lookup_widget(objet,"MT_modifprenom");
MT_modifnom=lookup_widget(objet,"MT_modifnom");
MT_modifmail=lookup_widget(objet,"MT_modifmail");
MT_modifniv=lookup_widget(objet,"MT_modifniv");
MT_modcal=lookup_widget(objet,"MT_modcal");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(MT_modifid)));
utilisateur p = chercher_utilisateur(id,"utilisateur.txt");
if(p.id!=-1){
gtk_combo_box_set_active(GTK_COMBO_BOX(MT_modifrole),p.role-1);//affichage
gtk_entry_set_text(GTK_ENTRY(MT_modifprenom),p.prenom);
gtk_entry_set_text(GTK_ENTRY(MT_modifnom),p.nom);
gtk_entry_set_text(GTK_ENTRY(MT_modifmail),p.email);
gtk_combo_box_set_active(GTK_COMBO_BOX(MT_modifniv),p.role==6?p.nv-1:-1);

}
else{
msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Utilisateur introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	break;
	}
}
}


void
on_treeview_utilisateur_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gint id;
	utilisateur u;
	GtkWidget *msg;
	GtkTreeModel *model=gtk_tree_view_get_model(treeview);
	if(gtk_tree_model_get_iter(model,&iter,path)){


	gtk_tree_model_get(GTK_LIST_STORE(model),&iter,0,&id,-1);


	u.id=id;

	msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_QUESTION,GTK_BUTTONS_OK_CANCEL,"Voulez-vous vraiment\nsupprimer cet utilisateur?");
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	supprimer_utilisateur(u,"utilisateur.txt");
	break;
	case GTK_RESPONSE_CANCEL:
	gtk_widget_destroy(msg);
	break;
	}
	}
}


void
on_MT_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeview, *af_utilisateur;


af_utilisateur=lookup_widget(objet,"af_utilisateur");

gtk_widget_destroy(af_utilisateur);
af_utilisateur=lookup_widget(objet,"af_utilisateur");
af_utilisateur=create_af_utilisateur();

gtk_widget_show(af_utilisateur);

treeview=lookup_widget(af_utilisateur,"treeview_utilisateur");

afficher_utilisateur(treeview,"utilisateur.txt");
}


void
on_MT_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *MT_ajoutid, *MT_ajoutrole, *MT_ajoutprenom, *MT_ajoutnom, *MT_ajoutmail, *MT_ajoutniv, *h, *f, *MT_j, *MT_m, *MT_a, *check, *msg;
utilisateur u;
guint day, month, year;
MT_ajoutid=lookup_widget(objet,"MT_ajoutid");
MT_ajoutrole=lookup_widget(objet,"MT_ajoutrole");
MT_ajoutprenom=lookup_widget(objet,"MT_ajoutprenom");
MT_ajoutnom=lookup_widget(objet,"MT_ajoutnom");
MT_ajoutmail=lookup_widget(objet,"MT_ajoutmail");
MT_ajoutniv=lookup_widget(objet,"MT_ajoutniv");
MT_j=lookup_widget(objet,"MT_j");
MT_m=lookup_widget(objet,"MT_m");
MT_a=lookup_widget(objet,"MT_a");
h=lookup_widget(objet,"h");
f=lookup_widget(objet,"f");
check=lookup_widget(objet,"check");

u.id=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MT_ajoutid));
strcpy(u.prenom,gtk_entry_get_text(GTK_ENTRY(MT_ajoutprenom)));
strcpy(u.nom,gtk_entry_get_text(GTK_ENTRY(MT_ajoutnom)));
strcpy(u.email,gtk_entry_get_text(GTK_ENTRY(MT_ajoutmail)));
u.sexe=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(h))?0:1;
u.d.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MT_j));
u.d.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MT_m));
u.d.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(MT_a));
u.role = gtk_combo_box_get_active(GTK_COMBO_BOX(MT_ajoutrole))+1;
u.nv = u.role==6?gtk_combo_box_get_active(GTK_COMBO_BOX(MT_ajoutniv))+1:0;

if(gtk_toggle_button_get_active(GTK_CHECK_BUTTON(check)))
ajouter_utilisateur(u,"utilisateur.txt");
else{
msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"Confirmation requise");
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	break;
	}
}
}


void
on_MT_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *MT_cherid, *MT_cherrole, *MT_cherprenom, *MT_chernom, *MT_chermail, *MT_cherniv, *MT_chersexe, *MT_cherdate, *msg;
char date_naissance[20], sexe[20], role[30], niveau[20];
MT_cherid=lookup_widget(objet,"MT_cherid");
MT_cherrole=lookup_widget(objet,"MT_cherrole");
MT_cherprenom=lookup_widget(objet,"MT_cherprenom");
MT_chernom=lookup_widget(objet,"MT_chernom");
MT_chermail=lookup_widget(objet,"MT_chermail");
MT_chersexe=lookup_widget(objet,"MT_chersexe");
MT_cherdate=lookup_widget(objet,"MT_cherdate");
MT_cherniv=lookup_widget(objet,"MT_cherniv");
int id = atoi(gtk_entry_get_text(GTK_ENTRY(MT_cherid)));
utilisateur p = chercher_utilisateur(id,"utilisateur.txt");
if (p.id==-1){
msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"ID introuvable");
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	break;
	}
}
else{
sprintf(role,p.role==1?"Admin":p.role==2?"Technicien":p.role==3?"Responsable réclamations":p.role==4?"Agent de foyer":p.role==5?"Agent de restaurant":"Etudiant");
gtk_label_set_text(GTK_LABEL(MT_cherrole),role);
gtk_label_set_text(GTK_LABEL(MT_cherprenom),p.prenom);
gtk_label_set_text(GTK_LABEL(MT_chernom),p.nom);
gtk_label_set_text(GTK_LABEL(MT_chermail),p.email);
sprintf(sexe,p.sexe==0?"Homme":"Femme");
gtk_label_set_text(GTK_LABEL(MT_chersexe),sexe);
sprintf(date_naissance,"%d/%d/%d",p.d.j,p.d.m,p.d.a);
gtk_label_set_text(GTK_LABEL(MT_cherdate),date_naissance);
sprintf(niveau,p.role==6?(p.nv==1?"1ère année":"%déme année"):"Employé",p.nv);
gtk_label_set_text(GTK_LABEL(MT_cherniv),niveau);
}
}




void
on_MT_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *aj_utilisateur, *af_utilisateur;
af_utilisateur=lookup_widget(objet,"af_utilisateur");
aj_utilisateur=lookup_widget(objet,"aj_utilisateur");
aj_utilisateur=create_aj_utilisateur();
gtk_widget_show(aj_utilisateur);
}


void
on_MT_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *mod_utilisateur, *af_utilisateur;
af_utilisateur=lookup_widget(objet,"af_utilisateur");
mod_utilisateur=lookup_widget(objet,"mod_utilisateur");
mod_utilisateur=create_mod_utilisateur();
gtk_widget_show(mod_utilisateur);
}


void
on_MT_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *recherche, *af_utilisateur;
af_utilisateur=lookup_widget(objet,"af_utilisateur");
recherche=lookup_widget(objet,"recherche");
recherche=create_recherche();
gtk_widget_show(recherche);
}


void
on_MT_nb_etudiant_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *msg;
char str[1000], ch[1000]="";
strcpy(ch,nombre_etudiant("utilisateur.txt"));
sprintf(str,"%s",ch);
msg=gtk_message_dialog_new(GTK_WINDOW(user_data),GTK_DIALOG_MODAL,GTK_MESSAGE_INFO,GTK_BUTTONS_OK,str);
	switch(gtk_dialog_run(GTK_DIALOG(msg)))
	{
	case GTK_RESPONSE_OK:
	gtk_widget_destroy(msg);
	break;
	}
}
