#include <gtk/gtk.h>

void
on_MT_button_mod_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_utilisateur_row_activated  (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_MT_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_button_aj_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_button5_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_MT_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_rechercher_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_MT_nb_etudiant_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);
